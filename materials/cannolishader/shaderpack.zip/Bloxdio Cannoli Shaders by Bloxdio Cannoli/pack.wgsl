fn pack_hash3(b: vec3i) -> f32 {
var h = u32(b.x) * 747796405u + u32(b.y) * 28997533u + u32(b.z) * 1911520717u;
h = h ^ (h >> 16u);
h = h * 2246822519u;
h = h ^ (h >> 13u);
return f32(h & 4095u) / 4095.0;
}
fn pack_hash(p: vec3f) -> f32 {
return fract(sin(dot(p, vec3f(12.9898, 78.233, 37.719))) * 43758.5453);
}
fn pack_cinematicGrade(colourIn: vec3f) -> vec3f {
let luma = vec3f(0.2126, 0.7152, 0.0722);
let lum = dot(max(colourIn, vec3f(0.0)), luma);
let shadows = 1.0 - smoothstep(0.08, 0.65, lum);
let highlights = smoothstep(0.25, 1.2, lum);
var c = colourIn * mix(vec3f(1.0), vec3f(0.94, 0.985, 1.055), shadows);
c *= mix(vec3f(1.0), vec3f(1.055, 1.015, 0.945), highlights);
c = (c - vec3f(0.18)) * 1.01 + vec3f(0.18);
let grey = dot(max(c, vec3f(0.0)), luma);
return max(mix(vec3f(grey), c, 1.2), vec3f(0.0));
}
fn bloxdTerrainSurface(s: BloxdSurfaceIn) -> BloxdSurface {
var out = bloxdDefaultSurface(s);
let worldBlock = bloxdFaceBlock(s.position, s.normal);
let blockNoise = pack_hash3(worldBlock);
out.colour *= mix(0.97, 1.03, blockNoise);
let worldPos = bloxdWorldPosition(s.position);
let pixelNoise = pack_hash(floor(worldPos * 4.0));
out.colour *= mix(0.97, 1.03, pixelNoise);
let side = 1.0 - abs(s.normal.y);
let sideShade = mix(1, 0.78, clamp(side, 0.0, 0.5));
out.colour *= sideShade;
return out;
}
fn sh_unlift(y: f32) -> f32 {
let t = clamp(1.0 - clamp(y, 0.0, 1.0), 0.0, 1.0);
let c = pow(t, 1.0 / 3.0);
return clamp(3.0 * (1.0 - c) / (3.0 - 2.0 * c), 0.0, 1.0);
}
fn canopyCover(encoded: f32) -> f32 {
return clamp((1.0 - clamp(encoded, 0.0, 1.0)) / 0.0035, 0.0, 1.0) * smoothstep(0.35, 0.6, encoded);
}
fn bloxdTerrainLight(s: BloxdSurface, l: BloxdLightIn) -> BloxdLight {
var out = bloxdDefaultLight(s, l);
#ifdef BLOXD_LIGHTING
let sky = clamp(l.skyLight, 0.0, 1.0);
let block = clamp(max(l.blockLight.r, max(l.blockLight.g, l.blockLight.b)), 0.0, 1.0);
let held = clamp(max(l.heldLight.r, max(l.heldLight.g, l.heldLight.b)), 0.0, 0.8);
let darkness = (0.95 - sky) * (1 - block) * (2 - held);
var shade = darkness * 1.1 - clamp(block * 1.5, 0.5, 2);
shade = clamp(shade, 0, 1.3);
out.colour *= mix(vec3f(1.0), vec3f(0.40, 0.43, 0.50), shade);
let covered = canopyCover(l.skyLight) - block - held;
let shadowVis = 1.0 - covered * 0.2;
out.colour *= shadowVis;
out.colour = pack_cinematicGrade(out.colour);
#endif
return out;
}
const PACK_WAVE_HEIGHT = 1.0;
fn pack_waterHash2(p: vec2f) -> f32 {
return fract(sin(dot(p, vec2f(127.1, 311.7))) * 43758.5453);
}
fn pack_waterValueNoise(p: vec2f) -> f32 {
let cell = floor(p);
let f = fract(p);
let u = f * f * (vec2f(3.0) - 2.0 * f);
let a = pack_waterHash2(cell);
let b = pack_waterHash2(cell + vec2f(1.0, 0.0));
let c = pack_waterHash2(cell + vec2f(0.0, 1.0));
let d = pack_waterHash2(cell + vec2f(1.0, 1.0));
return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}
fn pack_waterWarp(p: vec2f, t: f32) -> vec2f {
let q = p * 0.08 + vec2f(t * 0.04, -t * 0.025);
return vec2f(
pack_waterValueNoise(q) - 0.5,
pack_waterValueNoise(q + vec2f(31.7, 12.3)) - 0.5
) * 7.0;
}
fn pack_waterField(pIn: vec2f, t: f32, reach: f32) -> vec3f {
let warpA = pack_waterWarp(pIn, t);
let warpB = pack_waterWarp(pIn * 1.73 + vec2f(19.3, 7.1), -t * 0.63);
let p = pIn + warpA * 0.58 + warpB * 0.18;
let ampMod = 0.55 + 0.9 * pack_waterValueNoise(pIn * 0.045 + vec2f(5.0, 7.0));
var height = 0.0;
var slope = vec2f(0.0);
var freq = 1.4;
var amp = 0.032;
for (var i = 0; i < 6; i++) {
let fi = f32(i);
let fade = 1.0 - smoothstep(0.55, 2.6, freq * reach);
let dir = vec2f(
cos(fi * 2.39996 + 0.4),
sin(fi * 2.39996 + 0.4)
);
let phase = dot(dir, p) * freq + t * (1.2 + fi * 0.55) + fi * 1.7;
height += sin(phase) * amp * fade;
slope += dir * (cos(phase) * amp * freq * fade);
freq *= 1.62;
amp *= 0.64;
}
let cell = floor(p / 7.0);
let ringVisibility = 1.0 - smoothstep(1.0, 4.0, reach);
for (var x = -1; x <= 1; x++) {
for (var z = -1; z <= 1; z++) {
let c = cell + vec2f(f32(x), f32(z));
let h = pack_waterHash2(c + vec2f(13.7, 5.1));
let offsetX = pack_waterHash2(c + vec2f(7.1, 17.4));
let offsetZ = pack_waterHash2(c + vec2f(23.3, 9.2));
let center = (c + vec2f(offsetX, offsetZ)) * 7.0;
let delta = p - center;
let radius = max(length(delta), 0.001);
let ringFreq = 2.0 + h * 1.5;
let phase = radius * ringFreq - t * (0.9 + h * 0.85) + h * 6.2831853;
let decay = 0.045 + h * 0.035;
let radialFade = (1.0 - smoothstep(5.3, 6.85, radius))
* exp(-radius * decay);
let ringFade = 1.0 - smoothstep(1.0, 4.0, ringFreq * reach);
let ringAmp = 0.055 * (0.65 + h * 0.7) * ringVisibility * ringFade;
height += sin(phase) * ringAmp * radialFade;
let radialSlope = cos(phase) * ringFreq - sin(phase) * decay;
slope += delta / radius * radialSlope * ringAmp * radialFade;
}
}
height *= ampMod * PACK_WAVE_HEIGHT;
slope *= ampMod * PACK_WAVE_HEIGHT;
return vec3f(height, slope.x, slope.y);
}
fn pack_waterSlope(pIn: vec2f, t: f32, reach: f32) -> vec2f {
return pack_waterField(pIn, t, reach).yz;
}
fn bloxdLiquidSurface(s: BloxdSurfaceIn) -> BloxdSurface {
var out = bloxdDefaultSurface(s);
let worldPos = bloxdWorldPosition(s.position);
let t = bloxdSeconds();
if (abs(s.normal.y) > 0.5) {
let waves = pack_waterField(worldPos.xz, t, 0.0);
let rippleContrast = clamp(waves.x * 0.22, -0.07, 0.07);
out.colour *= 1.0 + rippleContrast;
}
let behind = bloxdOpaqueBehind();
if (behind.found) {
let thickness = distance(behind.position, s.position);
let absorb = exp(-thickness * vec3f(0.06, 0.025, 0.01));
out.colour *= absorb;
} else {
out.colour = mix(out.colour, vec3f(0.40, 0.44, 0.68), 0.65);
}
out.colour = clamp(out.colour, vec3f(0.0), vec3f(0.65));
#ifdef BLOXD_ALPHA
out.alpha = s.alpha;
#endif
return out;
}
fn bloxdLiquidLight(s: BloxdSurface, l: BloxdLightIn) -> BloxdLight {
var out = bloxdDefaultLight(s, l);
#ifdef BLOXD_LIGHTING
let baseN = normalize(l.normal);
let worldPos = bloxdWorldPosition(l.position);
let toPos = l.position - bloxdEyePosition();
let dist = max(length(toPos), 0.001);
let v = toPos / dist;
let reach = dist * 0.004 / max(abs(v.y), 0.2);
let waveField = pack_waterField(worldPos.xz, bloxdSeconds(), reach);
let slope = waveField.yz;
let rippleN = normalize(vec3f(-slope.x, 1.0, -slope.y));
let rippleStrength = clamp(baseN.y, 0.0, 1.0) * 0.65;
let n = normalize(mix(baseN, rippleN, rippleStrength));
let sunLen = length(bloxdSunDirection());
if (sunLen > 0.5) {
let sunDir = bloxdSunDirection() / sunLen;
let diffuse = max(dot(n, sunDir), 0.0);
let baseDiffuse = max(dot(baseN, sunDir), 0.0);
let variation = (diffuse - baseDiffuse) * 0.30 * l.skyLight;
out.colour *= 1.0 + clamp(variation, -0.12, 0.12);
}
#endif
return out;
}