fn bloxdTerrainSurface(s: BloxdSurfaceIn) -> BloxdSurface {
    var out = bloxdDefaultSurface(s);

    let colour = s.colour;
    let position = s.position;
    let normal = s.normal;
    let worldBlock = bloxdFragmentBlockPosition(s.position, s.normal); // Determines the integer block coordinate associated with the surface.
    let worldPos = bloxdWorldPosition(s.position); // Gets the surface position in world coordinates.
    let localPos = worldPos - vec3f(worldBlock);
    var id = s.textureId;
    
    var relativePos: vec2f;

    if (normal.y > 0.5) {
        relativePos = vec2f(localPos.x, localPos.z);
    } else if (normal.y < -0.5) {
        relativePos = vec2f(localPos.x, 1.0 - localPos.z);
    } else if (normal.x > 0.5) {
           relativePos = vec2f(localPos.z, localPos.y);
    } else if (normal.x < -0.5) {
       relativePos = vec2f(1.0 - localPos.z, localPos.y);
    }  else if (normal.z > 0.5) {
       relativePos = vec2f(1.0 - localPos.x, localPos.y);
    } else {
        relativePos = vec2f(localPos.x, localPos.y);
    }

    var rpx = relativePos.x;
    var rpy = relativePos.y;

    var r = colour.r;
    var g = colour.g;
    var b = colour.b;

    var wpx = worldPos.x;
    var wpy = worldPos.y;
    var wpz = worldPos.z;

    var wbx = worldBlock.x;
    var wby = worldBlock.y;
    var wbz = worldBlock.z;

    var px = position.x;
    var py = position.y;
    var pz = position.z;

    var nx = normal.x;
    var ny = normal.y;
    var nz = normal.z;

    if (ny == 1) {
        // the top of blocks

        out.colour = mix(colour, vec3f(1, 1, 1), 0.9); // tint white
        let pixelNoise = pack_hash(floor(worldPos * 8.0));
        out.colour *= mix(0.98, 1.01, pixelNoise); // add noise
    } else if (ny == 0) {
        // the left/right of blocks

        if (rpy > 0.3) {
            let pixelNoise = pack_hash(floor(worldPos * 8.0));
            let dither = step(0.35, pixelNoise);

            if (rpy < 0.5) { // give the dithering a threshold
                out.colour = mix(colour, vec3f(1.0), dither * 0.9); // dither
            } else {
                out.colour = mix(colour, vec3f(1, 1, 1), 0.9); // tint white
            }
            out.colour *= mix(0.98, 1.01, pixelNoise);
        }
    }

    return out;
}

fn bloxdTerrainLight(s: BloxdSurface, l: BloxdLightIn) -> BloxdLight {
    var out = bloxdDefaultLight(s, l);

    if bloxdLit() {
    }

    return out;
}

fn bloxdModelSurface(s: BloxdSurfaceIn) -> BloxdSurface {
    var out = bloxdDefaultSurface(s); // Gets the default surface properties to preserve the original appearance.
    var flags = s.flags;
    var id = s.textureId;

    let normal = s.normal;
    let worldPos = bloxdWorldPosition(s.position);

    var nx = normal.x;
    var ny = normal.y;
    var nz = normal.z;

    if (flags.flat || flags.held) {
        out.overlayColour = vec4f(1, 1, 1, 0.8);
    } else {
        if (ny > 0 && (nx < 0.1 && nx > -0.1) && (nz < 0.1 && nz > -0.1)) {
            out.colour = mix(out.colour, vec3f(1, 1, 1), 0.9); // tint white
            let pixelNoise = pack_hash(floor(worldPos * 8.0));
            out.colour *= mix(0.98, 1.01, pixelNoise); // add noise
        }
    }
    return out;
}

fn bloxdModelLight(s: BloxdSurface, l: BloxdLightIn) -> BloxdLight {
    var out = bloxdDefaultLight(s, l); // Gets the default surface properties to preserve the original appearance.

    if bloxdLit() {
    }
    return out;
}


fn pack_hash3(b: vec3i) -> f32 { // Converts integer block coordinates into a repeatable pseudorandom value.
    var h = u32(b.x) * 747796405u + u32(b.y) * 28997533u + u32(b.z) * 1911520717u; // Combines the X, Y, and Z coordinates using integer arithmetic.
    h = h ^ (h >> 16u); // Shifts and XORs bits to mix the coordinate values.
    h = h * 2246822519u; // Multiplies by a constant to further scramble the bits.
    h = h ^ (h >> 13u); // Mixes the bits again to improve the distribution of results.
    return f32(h & 4095u) / 4095.0; // Converts the lowest 12 bits into a floating-point value between 0.0 and 1.0.
}

fn pack_hash(p: vec3f) -> f32 { // Converts floating-point coordinates into a pseudorandom value.
    return fract(sin(dot(p, vec3f(12.9898, 78.233, 37.719))) * 43758.5453); // Combines the coordinates and hashes them into a value between 0.0 and 1.0.
}