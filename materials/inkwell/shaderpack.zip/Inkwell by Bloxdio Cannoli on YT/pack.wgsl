/*
Shaders by @BloxdioCannoli on YT, from bloxdiocannoli.github.io
*/

fn bloxdTerrainSurface(s: BloxdSurfaceIn) -> BloxdSurface {
    var out = bloxdDefaultSurface(s);
    out.colour = vec3f(dot(out.colour, vec3f(0.299, 0.587, 0.114)));
    return out;
}