// Ripples for shading only: value noise over a lattice whose corners each oscillate at their own speed and phase,
// so the shimmer stays in place with no travel direction. Two rotated octaves, with analytic derivatives for the
// normal. Built from integer world cells, so the waves keep their precision far from spawn and don't jump when noa
// rebases its origin.

const CELLS_PER_BLOCK = 8;      // shading cells along each axis of a block
const HASH_PERIOD = 289;        // lattice cells; corner ids wrap here, where the hash's float precision still holds
const TAU = 6.2831853;

// An octave is a lattice turned off the block grid, given by the whole lattice cells (SHIFT) that STRIDE shading cells
// along x move it by, so whole strides can stay integers. Neither lattice lines up with the grid or with the other.
const COARSE_STRIDE = 2000;
const COARSE_SHIFT = vec2i(117, 44);    // 0.5 lattice cells per block, turned 20.6 degrees
const FINE_STRIDE = 3700;
const FINE_SHIFT = vec2i(459, 312);     // 1.2 lattice cells per block, turned 34.2 degrees

fn waveHash(corner: vec2f) -> vec2f {
    var mixed = fract(corner.xyx * vec3f(0.1031, 0.103, 0.0973));
    mixed += dot(mixed, mixed.yzx + 33.33);
    return fract((mixed.xx + mixed.yz) * mixed.zy);
}

// A lattice corner's current value, in [0, 1].
fn waveCorner(id: vec2i) -> f32 {
    let hash = waveHash(vec2f(((id % HASH_PERIOD) + HASH_PERIOD) % HASH_PERIOD));
    // Whole cycles per wrap (0.31 to 0.91 rad/s), so the wrap is seamless and sin's argument stays within one turn.
    let cycles = floor(176.0 + hash.x * 345.0);
    return 0.5 + 0.5 * sin(TAU * fract(bloxdTime() / bloxdTimeWrap * cycles + hash.y));
}

// Value noise over the oscillating lattice, offset by `base` whole lattice cells: d(value)/d(point) in xy, the value
// in z. The quintic blend keeps both the value and its gradient continuous.
fn waveNoise(point: vec2f, base: vec2i) -> vec3f {
    let whole = floor(point);
    let fraction = point - whole;
    let id = vec2i(whole) + base;
    let corner00 = waveCorner(id);
    let corner10 = waveCorner(id + vec2i(1, 0));
    let corner01 = waveCorner(id + vec2i(0, 1));
    let corner11 = waveCorner(id + vec2i(1, 1));
    let blend = fraction * fraction * fraction * (fraction * (fraction * 6.0 - 15.0) + 10.0);
    let blendSlope = 30.0 * fraction * fraction * (fraction * (fraction - 2.0) + 1.0);
    let k0 = corner10 - corner00;
    let k1 = corner01 - corner00;
    let k2 = corner00 - corner10 - corner01 + corner11;
    let value = corner00 + k0 * blend.x + k1 * blend.y + k2 * blend.x * blend.y;
    return vec3f(blendSlope * (vec2f(k0, k1) + k2 * blend.yx), value);
}

// One octave at the centre of a world shading cell (x, z): the slope along world x and z, then the value.
fn waveOctave(cell: vec2i, stride: i32, shift: vec2i, offset: vec2f) -> vec3f {
    let scale = length(vec2f(shift)) * CELLS_PER_BLOCK / f32(stride);    // lattice cells per block
    let rotation = normalize(vec2f(shift));                             // cos, sin
    let rest = ((cell % stride) + stride) % stride;
    // The hash wraps at HASH_PERIOD anyway, and wrapping the count first keeps base from overflowing.
    let strideCount = ((cell - rest) / stride) % HASH_PERIOD;
    let base = strideCount.x * shift + strideCount.y * vec2i(-shift.y, shift.x);
    let point = (vec2f(rest) + 0.5) / CELLS_PER_BLOCK;
    let rotated = vec2f(rotation.x * point.x - rotation.y * point.y, rotation.y * point.x + rotation.x * point.y);
    let noise = waveNoise(rotated * scale + offset, base);
    // Rotated back to world axes, and scaled by the chain rule, since the gradient is per lattice cell.
    let slope = vec2f(rotation.x * noise.x + rotation.y * noise.y, rotation.x * noise.y - rotation.y * noise.x);
    return vec3f(slope * scale, noise.z);
}

// The height field's slope along world x and z, and its height normalised to roughly -1 to 1. Features are about
// 2 and 0.8 blocks across. The fine octave fades out with distance (`fine` is 1 up close, 0 far), where its ripples
// are smaller than a pixel, and isn't worked out at all once it's gone; its average height stands in for it.
const FINE_NEAR = 24.0;
const FINE_FAR = 40.0;

fn waveField(cell: vec2i, eyeDistance: f32) -> vec3f {
    let coarse = waveOctave(cell, COARSE_STRIDE, COARSE_SHIFT, vec2f(0.0));
    let fineWeight = 1.0 - smoothstep(FINE_NEAR, FINE_FAR, eyeDistance);
    var fine = vec3f(0.0, 0.0, 0.5);
    if (fineWeight > 0.0) {
        fine = mix(fine, waveOctave(cell, FINE_STRIDE, FINE_SHIFT, vec2f(37.2, 17.8)), fineWeight);
    }
    let height = 0.25 * coarse.z + 0.1 * fine.z;
    return vec3f(0.25 * coarse.xy + 0.1 * fine.xy, (height - 0.17) * 5.0);
}
