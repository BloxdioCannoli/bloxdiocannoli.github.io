// Water, ported from the WebGL material plugin on the water-shader branch (WaterRenderMaterial.ts): pixel-snapped
// ripples, a fresnel sky reflection, a soft sun sheen and a colour that deepens with the water below, plus a soft
// white edge where it meets land. No sparkles or pinpoint glints, so it stays as calm and soft as the land. Bright
// and clear to sit with the brightened land. Shading only. Liquid keeps alpha in every variant, so this runs in
// strict games too.

const WATER_COLOUR = vec3f(0.5, 0.5, 0.8);      // Water's registered colour, which the depth tint replaces
const SHALLOW_TINT = vec3f(0.58, 0.92, 0.92);
const DEEP_TINT = vec3f(0.05, 0.18, 0.5);
const DEPTH_DARKEN = 0.32;                      // how fast it turns deep: about a third by 1 block, most of the way by 6
const WATER_ALPHA = 0.9;                        // Water's registered alpha, which the opacities below replace
const SHALLOW_OPACITY = 0.3;                    // at the shore, so you see the bottom
const DEEP_OPACITY = 0.97;                      // in deep water
const CREST_GAIN = 0.02;                        // crests catch slightly more light than troughs
const REFLECTIVITY = 0.45;                      // how much of the fresnel term shows the sky
const SKY_REFLECTION_COLOUR = vec3f(0.68, 0.79, 0.94);
const GLINT_COLOUR = vec3f(1.0, 0.97, 0.88);
const FOAM_COLOUR = vec3f(0.97, 0.99, 1.0);
const FOAM_WIDTH = 0.45;                         // blocks of shallow water the white edge fades out over
const FOAM_SOLID = 0.1;                          // right against the land it's solid white
// Rings where leaves land: the water is split into cells, and some cells get a ring now and then that spreads and
// fades, at a random spot and time. On the same 8x8 shading cells as the ripples, so the rings are pixel-snapped too.
const LANDING_RINGS = true;                      // false switches them off
const RING_CELL = 4;                             // blocks; each cell has at most one ring at a time
const RING_CHANCE = 0.45;                        // share of cells that get rings
const RING_EVERY = 5.0;                          // seconds between a cell's rings
const RING_SIZE = 1.1;                           // blocks across when it fades out
const RING_STRENGTH = 0.4;

// The surface hook's results for the light hook, which runs later in the same fragment.
struct WaterShade {
    depthFade: f32,
    crest: f32,         // wave height, roughly -1 to 1
    fresnel: f32,
    glint: f32,         // before sky exposure, which only the light hook knows
    foam: f32,
    ring: f32,
}
var<private> shade: WaterShade;

// 0 to 1: how much of a landing ring this shading cell is on. Worked out in whole world cells, so it keeps its
// precision far from spawn and doesn't jump when noa rebases its origin.
fn landingRing(localCell: vec3f) -> f32 {
    if (!LANDING_RINGS) {
        return 0.0;
    }
    let shading = vec3i(localCell).xz + bloxdOriginOffset().xz * CELLS_PER_BLOCK;
    let span = RING_CELL * CELLS_PER_BLOCK;
    let cell = vec2i(floor(vec2f(shading) / f32(span)));
    let h = cellHash(vec3i(cell.x, 4099, cell.y));
    if (hashUnit(h) > RING_CHANCE) {
        return 0.0;
    }
    let h2 = nextHash(h);
    let h3 = nextHash(h2);
    let h4 = nextHash(h3);
    // Where in the cell it lands, kept off the edges so the whole ring stays inside.
    let centre = (vec2f(0.3) + 0.4 * vec2f(hashUnit(h2), hashUnit(h3))) * f32(span);
    let here = vec2f(shading - cell * span) + 0.5;
    let age = fract(bloxdTime() / RING_EVERY + hashUnit(h4));
    let radius = age * RING_SIZE * 0.5 * f32(CELLS_PER_BLOCK);
    let gap = abs(length(here - centre) - radius);
    let inner = abs(length(here - centre) - radius * 0.55);
    let ring = max(1.0 - smoothstep(0.4, 1.2, gap), 0.6 * (1.0 - smoothstep(0.4, 1.0, inner)));
    return ring * (1.0 - age) * smoothstep(0.0, 0.06, age);
}

fn waterShade(surface: BloxdSurfaceIn) -> WaterShade {
    // Half a cell inside the face, so a side face doesn't flicker between the cells either side of it.
    let localCell = floor(surface.position * CELLS_PER_BLOCK - surface.normal * 0.5);
    let cellCentre = (localCell + 0.5) / CELLS_PER_BLOCK;
    let wave = waveField(vec3i(localCell).xz + bloxdOriginOffset().xz * CELLS_PER_BLOCK, distance(bloxdEyePosition(), cellCentre));

    // Top faces take the full wave normal, side faces only a mild tilt.
    let waveNormal = normalize(vec3f(-wave.x, 1.0, -wave.y));
    let upness = clamp(surface.normal.y, 0.0, 1.0);
    let shadeNormal = normalize(surface.normal + (waveNormal - vec3f(0.0, 1.0, 0.0)) * mix(0.25, 1.0, upness));
    // From the cell centre, so fresnel and glint pixelate with the waves.
    let toEye = normalize(bloxdEyePosition() - cellCentre);

    // Schlick, with water's reflectance head-on.
    let grazing = 1.0 - clamp(dot(toEye, shadeNormal), 0.0, 1.0);
    let fresnel = 0.02 + 0.98 * grazing * grazing * grazing * grazing * grazing;

    // A broad sheen only, fading as the sun nears the horizon. With no sun the direction is zero.
    let halfVector = toEye + bloxdSunDirection();
    // Not normalize(): the sum is zero when the sun is exactly opposite the eye, and that would be NaN.
    let nDotH = clamp(dot(shadeNormal, halfVector) / max(length(halfVector), 1e-4), 0.0, 1.0);
    let sunUp = clamp(bloxdSunDirection().y * 4.0, 0.0, 1.0);
    let glint = 0.05 * pow(nDotH, 24.0) * sunUp;

    // Vertical thickness, per pixel rather than per cell, so shorelines keep a smooth ramp. Open sky behind the water
    // reads as deep.
    let behind = bloxdOpaqueBehind();
    let depth = select(64.0, max(surface.position.y - behind.position.y, 0.0), behind.found);
    let depthFade = 1.0 - exp(-depth * DEPTH_DARKEN);

    // A soft white edge where the water meets land, its width breathing a little with the ripples.
    let foam = (1.0 - smoothstep(FOAM_SOLID, FOAM_WIDTH * (1.0 + 0.2 * wave.z), depth)) * step(0.5, upness);

    return WaterShade(depthFade, wave.z, fresnel, glint, foam, landingRing(localCell) * step(0.5, upness));
}

fn bloxdLiquidSurface(surface: BloxdSurfaceIn) -> BloxdSurface {
    shade = waterShade(surface);
    var out = bloxdDefaultSurface(surface);
    // The depth tint in the light hook replaces Water's registered colour.
    out.colour = surface.colour / WATER_COLOUR;
    // Clearer looking straight down and over shallows; the sheen and the white edge stay visible.
    out.alpha = clamp(surface.alpha / WATER_ALPHA * mix(0.95, 1.05, shade.fresnel) * mix(SHALLOW_OPACITY, DEEP_OPACITY, shade.depthFade)
        + shade.glint * 0.5, 0.0, 1.0);
    out.alpha = max(max(out.alpha, shade.foam * 0.95), shade.ring * 0.6);
    return out;
}

fn bloxdLiquidLight(surface: BloxdSurface, light: BloxdLightIn) -> BloxdLight {
    // Cave water doesn't reflect or glint the open sky. skyLight is tone-mapped: these are 0.4 and 0.9 before it.
    let skyExposure = smoothstep(0.45, 0.98, light.skyLight);
    // After lighting, as the old plugin did: there, tinting before it let the untinted ambient wash the colour out.
    var colour = light.litColour * mix(SHALLOW_TINT, DEEP_TINT, shade.depthFade);
    colour *= 1.0 + shade.crest * CREST_GAIN;
    // Tinted by the sky light, so the reflection darkens at night. After the depth tint, so it stays crisp over deep water.
    colour = mix(colour, light.skyLightColour * SKY_REFLECTION_COLOUR, shade.fresnel * REFLECTIVITY * skyExposure);
    colour += shade.glint * skyExposure * light.skyLightColour * GLINT_COLOUR;
    // litColour is the water's own light and corner shading, so the foam dims in shade and at night like the land.
    colour = mix(colour, light.litColour * FOAM_COLOUR, shade.foam);
    colour = mix(colour, light.skyLightColour * SKY_REFLECTION_COLOUR * 1.15, shade.ring * RING_STRENGTH * mix(0.4, 1.0, skyExposure));

    var out = bloxdDefaultLight(surface, light);
    // Water in a tree's shadow, the same test as on land.
    let underTree = clamp((1.0 - light.skyLight) / CANOPY_SPREAD, 0.0, 1.0) * smoothstep(0.35, 0.6, light.skyLight) > 0.3;
    out.colour = withFallingLeaves(bloxdApplyFog(brighten(colour) + surface.emission, light), light.position, underTree);
    return out;
}
