// Falling leaves drifting near the player. Packs can't add anything to the world, so each pixel of terrain or water
// looks along the line from the eye to itself for a leaf floating in front, and draws that leaf instead if there is
// one. The air is split into cells that slide down over time, so every leaf falls; some cells hold a leaf, placed and
// coloured by the cell's hash, which sways side to side and flips as it goes. Packs can't see where trees are, so a
// leaf is only drawn over a leaf block or over ground in a tree's shadow: that keeps them around trees, never over
// bare ground or the sky, and close, within LEAF_RANGE of the eye.

const FALLING_LEAVES = true;   // false switches them off, and costs nothing
const LEAF_RANGE = 10.0;       // blocks from the eye they're drawn to
const LEAF_STEPS = 6;          // looks along each line; fewer is cheaper but can miss leaves
const LEAF_CELL = 3.0;         // blocks; each cell holds at most one leaf
const LEAF_CHANCE = 0.3;       // share of cells holding one
const LEAF_SIZE = 0.09;        // half the width of a leaf, in blocks
const LEAF_FALL = 0.6;         // blocks per second

// Greens with a few autumn ones.
fn leafColour(pick: u32) -> vec3f {
    switch pick % 5u {
        case 0u: { return vec3f(0.36, 0.62, 0.16); }
        case 1u: { return vec3f(0.5, 0.72, 0.2); }
        case 2u: { return vec3f(0.72, 0.78, 0.22); }
        case 3u: { return vec3f(0.88, 0.62, 0.18); }
        default: { return vec3f(0.8, 0.38, 0.14); }
    }
}

fn withFallingLeaves(colour: vec3f, position: vec3f, nearTree: bool) -> vec3f {
    if (!FALLING_LEAVES || !nearTree) {
        return colour;
    }
    let eye = bloxdEyePosition();
    let toSurface = position - eye;
    let surfaceDistance = length(toSurface);
    let d = toSurface / max(surfaceDistance, 0.001);
    let reach = min(surfaceDistance, LEAF_RANGE);
    let t = bloxdTime();
    let fall = t * LEAF_FALL;
    // A frame for measuring how far a leaf sits off the line of sight.
    var across = cross(d, vec3f(0.0, 1.0, 0.0));
    if (dot(across, across) < 0.0001) {
        across = vec3f(1.0, 0.0, 0.0);
    }
    across = normalize(across);
    let along = cross(across, d);
    let origin = vec3f(bloxdOriginOffset() % vec3i(3072));
    let stride = LEAF_RANGE / f32(LEAF_STEPS);

    for (var i = 0; i < LEAF_STEPS; i++) {
        let s = (f32(i) + 0.5) * stride;
        if (s > reach + LEAF_CELL) {
            break;
        }
        // In the sliding frame the leaves sit still; in the world they fall.
        let sliding = eye + origin + d * s + vec3f(0.0, fall, 0.0);
        let cell = vec3i(floor(sliding / LEAF_CELL));
        let h = cellHash(cell + vec3i(0, 0, 7919));
        if (hashUnit(h) > LEAF_CHANCE) {
            continue;
        }
        let h2 = nextHash(h);
        let h3 = nextHash(h2);
        let h4 = nextHash(h3);
        let phase = hashUnit(h4) * 6.2831853;
        let inCell = 0.25 + 0.5 * vec3f(hashUnit(h2), hashUnit(h3), hashUnit(nextHash(h4)));
        let sway = vec3f(sin(t * 1.3 + phase) * 0.35, 0.0, cos(t * 0.9 + phase * 1.7) * 0.35);
        let leaf = (vec3f(cell) + inCell) * LEAF_CELL - vec3f(0.0, fall, 0.0) + sway - origin;

        let offset = leaf - eye;
        let depth = dot(offset, d);
        if (depth < 0.3 || depth > surfaceDistance - 0.05) {
            continue;
        }
        let off = offset - d * depth;
        var onLeaf = vec2f(dot(off, across), dot(off, along));
        // Spinning, and flipping over, which narrows it as it turns edge-on.
        let spin = t * 1.6 + phase;
        onLeaf = vec2f(cos(spin) * onLeaf.x - sin(spin) * onLeaf.y, sin(spin) * onLeaf.x + cos(spin) * onLeaf.y);
        let flip = max(abs(cos(t * 2.2 + phase * 2.3)), 0.25);
        if (abs(onLeaf.x) < LEAF_SIZE * flip && abs(onLeaf.y) < LEAF_SIZE) {
            let sun = bloxdSunDirection();
            let lightLevel = mix(0.45, 1.05, smoothstep(0.0, 0.2, sun.y)) * mix(0.85, 1.1, hashUnit(h3));
            return leafColour(h2) * lightLevel;
        }
    }
    return colour;
}
