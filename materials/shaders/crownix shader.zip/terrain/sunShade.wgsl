// Sun shade on terrain by face direction: faces towards the sun are warmed and faces turned away are cooled and
// darkened, following the sun through the day. Under trees and overhangs the sky light drops, so those spots get a
// soft shadow as if the sun were blocked, with sunspots drifting through it in the wind. Leaves shimmer as gusts run
// over them. Block light and held light shine through all of it, and caves and rooms are left alone. The shadows need
// Lighting on in the game: without it Bloxd sends no sky light. Falling leaves are drawn over the top (leaves.wgsl).

const SHADE_TINT = vec3f(0.76, 0.8, 0.88);   // multiplies sky-lit colour on faces turned from the sun
const SUN_TINT = vec3f(1.1, 1.04, 0.94);     // and on faces towards it
const CANOPY_TINT = vec3f(0.5, 0.56, 0.7);   // under trees and overhangs
const CANOPY_STRENGTH = 1.0;
const CANOPY_SPREAD = 0.0035;               // sky light lost that counts as full shade; smaller spreads it wider
const SUNSPOTS = 0.45;                       // how much light the drifting sunspots let through the shadow; 0 for none
const SUNSPOT_SPEED = 0.3;                   // how fast they drift; 1 is a breezy day
const LEAF_SHIMMER = 0.3;                    // how much gusts brighten and darken leaves as they pass; 0 for none
// Wind rolling over grass: soft, lighter bands sweep across the tops of grass blocks in gusts, the way wind brushes a
// meadow. Grass plants and flowers are drawn by a part of Bloxd that packs can't reach, so the ground carries it.
const GRASS_GUSTS = 0.16;                    // how much lighter a passing gust makes the grass; 0 for none
const GUST_DIRECTION = vec2f(0.92, 0.39);    // which way the wind blows across the ground
// dot(normal, sun) over which a face turns from shade to sun. A little past side-on, so a face the sun only grazes
// is half lit rather than in full shade.
const SHADE_FROM = -0.1;
const SUN_FROM = 0.35;

fn isGrassBlock(id: u32) -> bool {
    switch id {
        case 4u, 1694u, 1955u, 3071u, 3072u, 3073u, 3253u, 3254u: {
            return true;
        }
        default: {
            return false;
        }
    }
}

// 0 to 1: how much of a passing gust is on this spot of grass. Long soft bands across the wind, rolling along it.
fn grassGust(place: vec3f, t: f32) -> f32 {
    let along = dot(place.xz, GUST_DIRECTION);
    let across = dot(place.xz, vec2f(-GUST_DIRECTION.y, GUST_DIRECTION.x));
    let wave = mistNoise(vec2f(along * 0.22 - t * 1.4, across * 0.07), 10u);
    let gusting = 0.55 + 0.45 * sin(t * 0.23 + along * 0.01);
    return smoothstep(0.55, 0.85, wave) * gusting;
}

fn maxComponent(v: vec3f) -> f32 {
    return max(v.r, max(v.g, v.b));
}

fn bloxdTerrainLight(surface: BloxdSurface, light: BloxdLightIn) -> BloxdLight {
    let sun = bloxdSunDirection();
    let lit = smoothstep(SHADE_FROM, SUN_FROM, dot(light.normal, sun));
    let lamp = 1.0 - smoothstep(0.4, 0.9, maxComponent(max(light.blockLight, light.heldLight)));
    // Fades with the sun at the horizon, and is off at night and under a sky with no sun (zero direction).
    let day = smoothstep(0.0, 0.12, sun.y);
    var strength = day * smoothstep(0.4, 0.9, light.skyLight) * lamp;
    let t = bloxdTime() * WIND_SPEED;
    // Wrapped so the patterns keep their precision far from spawn.
    let place = light.position + vec3f(bloxdOriginOffset() % vec3i(4096));

    // Open sky is exactly 1. Under a canopy sky light seeps in from the sides, so after Bloxd's tone curve most of
    // the ground below only drops to level 14 (about 0.995). Counting that one lost level as shade puts the shadow
    // under the whole tree, straight down; caves are left alone.
    var covered = clamp((1.0 - light.skyLight) / CANOPY_SPREAD, 0.0, 1.0) * smoothstep(0.35, 0.6, light.skyLight);
    let underTree = covered > 0.3;
    if (covered > 0.01 && SUNSPOTS > 0.0) {
        let spots = smoothstep(0.58, 0.72, mistNoise(place.xz * 0.9 + vec2f(t * 0.4, t * 0.25) * SUNSPOT_SPEED, 8u));
        covered *= 1.0 - spots * SUNSPOTS * day;
    }
    let canopy = mix(vec3f(1.0), CANOPY_TINT, covered * CANOPY_STRENGTH * lamp * max(day, 0.3));

    var rustle = 1.0;
    if (LEAF_SHIMMER > 0.0 && isLeaf(light.blockId)) {
        let gust = mistNoise(place.xz * 0.7 + place.y * 0.4 + vec2f(t * 0.9, t * 0.55), 9u);
        rustle = 1.0 + (gust - 0.5) * 2.0 * LEAF_SHIMMER * WIND_STRENGTH;
    }

    if (GRASS_GUSTS > 0.0 && light.normal.y > 0.5 && isGrassBlock(light.blockId)) {
        rustle *= 1.0 + grassGust(place, t) * GRASS_GUSTS * mix(0.4, 1.0, day);
    }

    let shaded = light.litColour * mix(vec3f(1.0), mix(SHADE_TINT, SUN_TINT, lit), strength) * canopy * rustle;
    var out = bloxdDefaultLight(surface, light);
    let nearTree = isLeaf(light.blockId) || underTree;
    out.colour = withFallingLeaves(bloxdApplyFog(brighten(shaded) + surface.emission, light), light.position, nearTree);
    return out;
}
