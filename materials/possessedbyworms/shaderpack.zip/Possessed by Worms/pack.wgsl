/*
Shaders by @BloxdioCannoli on YT, from bloxdiocannoli.github.io
*/

#ifndef BLOXD_STRICT
fn bloxdTerrainVertex(v: BloxdVertexIn) -> BloxdVertex {
    var result = bloxdDefaultVertex(v);
    let world = bloxdWorldPosition(v.position);
    result.position.x += sin(world.x * 0.8 + bloxdSeconds() * 2.0) * 0.2;
    return result;
}

fn bloxdLiquidVertex(v: BloxdVertexIn) -> BloxdVertex {
    var result = bloxdDefaultVertex(v);
    let world = bloxdWorldPosition(v.position);
    result.position.x += sin(world.x * 0.8 + bloxdSeconds() * 2.0) * 0.2;
    return result;
}

fn bloxdModelVertex(v: BloxdVertexIn) -> BloxdVertex {
    var result = bloxdDefaultVertex(v);
    var flags = v.flags;
    let world = bloxdWorldPosition(v.position);
    if (flags.placed) {
        result.position.x += sin(world.x * 0.8 + bloxdSeconds() * 2.0) * 0.2;
    }
    return result;
}
#endif