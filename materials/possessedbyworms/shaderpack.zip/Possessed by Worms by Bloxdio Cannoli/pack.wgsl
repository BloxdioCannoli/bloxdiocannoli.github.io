/*
Shaders by @BloxdioCannoli on YT, from bloxdiocannoli.github.io
*/

#ifndef BLOXD_STRICT
fn bloxdTerrainVertex(v: BloxdVertexIn) -> BloxdVertex {
    var result = bloxdDefaultVertex(v);
    let world = bloxdWorldPosition(v.position);
    result.position.x += sin(world.x * 0.8 + bloxdSeconds() * 2.0) * 0.2;
    return result;
}
#endif